// File: src/background/service-worker.ts
import { TabManager } from "./tab-manager";
import { FocusedTabsManager } from "./focused-tabs-manager";
import { ProxyManager } from "./proxy-manager";
import { MessageHandler } from "./message-handler";
import { setupEventListeners } from "./event-listeners";

declare const browser: typeof chrome & any;

(function () {
  "use strict";

  const browserAPI = (function (): typeof chrome & any {
    if (typeof browser !== "undefined") return browser as any;
    if (typeof chrome !== "undefined") return chrome as any;
    throw new Error("No browser API available");
  })();

  // Initialize managers
  const tabManager = new TabManager(browserAPI);
  const focusedTabsManager = new FocusedTabsManager(browserAPI);
  const proxyManager = new ProxyManager(browserAPI);
  const messageHandler = new MessageHandler(
    tabManager,
    focusedTabsManager,
    proxyManager
  );

  // Setup all event listeners
  setupEventListeners(
    browserAPI,
    tabManager,
    focusedTabsManager,
    proxyManager,
    messageHandler
  );

  // Expose managers for content scripts and popup
  (globalThis as any).tabManager = tabManager;

  // ✅ FIX: Load groups từ storage khi browser khởi động lại
  (async () => {
    try {
      await tabManager.reloadFromStorage();
      const groups = tabManager.getGroups();

      // Nếu không có groups nào, tạo default group
      if (groups.length === 0) {
        console.log(
          "[ServiceWorker] No groups found, initializing defaults..."
        );
        await tabManager.initializeDefaultGroups();
      } else {
        console.log(
          `[ServiceWorker] Loaded ${groups.length} group(s) from storage`
        );
      }
    } catch (error) {
      console.error("[ServiceWorker] Failed to load groups on startup:", error);
    }
  })();
})();
